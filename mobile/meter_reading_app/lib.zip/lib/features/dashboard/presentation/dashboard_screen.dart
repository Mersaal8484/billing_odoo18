import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../app/providers.dart';
import '../../../shared/widgets/state_widgets.dart';
import '../../customers/domain/entities.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final assignments = ref.watch(assignmentsProvider(const AssignmentQuery()));
    final sync = ref.watch(syncSnapshotProvider);
    final user = ref.watch(currentUserProvider);
    final isReader = ref.watch(isReaderProvider);
    final isCollector = ref.watch(isCollectorProvider);
    final isSupervisor = ref.watch(isSupervisorProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الرئيسية'),
        actions: [
          IconButton(
            tooltip: 'الإعدادات',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => context.push('/settings'),
          ),
        ],
      ),
      body: assignments.when(
        loading: () => const LoadingState(),
        error: (e, _) => ErrorState(message: 'تعذر تحميل المهام: $e'),
        data: (list) {
          final total = list.length;
          final done =
              list.where((a) => a.status == AssignmentStatus.read).length;
          final pending =
              list.where((a) => a.status == AssignmentStatus.pending).length;
          final offline =
              sync.value?.connectivity.name == 'offline';
          final batch = sync.value?.batchPipeline;
          final pendingSync =
              (batch?.pending ?? 0) + (batch?.inProgress ?? 0);
          final synced = batch?.succeeded ?? 0;
          final failed = batch?.failed ?? 0;

          return Column(
            children: [
              OfflineBanner(
                offline: offline,
                pendingCount: pendingSync,
                onSyncNow: () => context.push('/sync'),
              ),

              // بطاقة ترحيب بالمستخدم
              if (user != null)
                Padding(
                  padding:
                      const EdgeInsets.fromLTRB(16, 12, 16, 0),
                  child: Card(
                    color: Theme.of(context)
                        .colorScheme
                        .primaryContainer
                        .withOpacity(0.4),
                    child: ListTile(
                      leading: CircleAvatar(
                        child: Text(
                          user.name.isNotEmpty
                              ? user.name[0].toUpperCase()
                              : '؟',
                        ),
                      ),
                      title: Text(user.name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold)),
                      subtitle: Text(
                        _roleLabel(isReader, isCollector, isSupervisor),
                        style: TextStyle(
                            color: Theme.of(context)
                                .colorScheme
                                .primary),
                      ),
                    ),
                  ),
                ),

              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    // بطاقة التقدم — فقط للكاشف
                    if (isReader) ...[
                      _ProgressCard(
                        total: total,
                        done: done,
                        pending: pending,
                        pendingSync: pendingSync,
                        synced: synced,
                        failed: failed,
                      ),
                      const SizedBox(height: 16),
                    ],

                    Text('مسارات العمل',
                        style:
                            Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),

                    GridView.count(
                      shrinkWrap: true,
                      crossAxisCount: 2,
                      childAspectRatio: 1.15,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      physics: const NeverScrollableScrollPhysics(),
                      children: [
                        // ✅ الكاشف — فقط إذا كان is_meter_reader
                        if (isReader)
                          _QuickAction(
                            icon: Icons.speed_rounded,
                            label: 'الكاشف',
                            subtitle: 'مهام القراءة',
                            badge: pending > 0 ? '$pending متبقي' : null,
                            onTap: () => context.push('/customers'),
                          ),

                        // ✅ المتحصل — فقط إذا كان is_collector
                        if (isCollector)
                          _QuickAction(
                            icon: Icons.qr_code_scanner_rounded,
                            label: 'المتحصل',
                            subtitle: 'QR والتحصيل',
                            onTap: () => context.push('/collector'),
                          ),

                        // ✅ المشرف — فقط إذا كان is_supervisor
                        if (isSupervisor)
                          _QuickAction(
                            icon: Icons.rule_folder_outlined,
                            label: 'المشرف',
                            subtitle: 'اعتماد ومتابعة',
                            onTap: () => context.push('/supervisor'),
                          ),

                        // المزامنة — للجميع
                        _QuickAction(
                          icon: Icons.sync_rounded,
                          label: 'المزامنة',
                          subtitle: 'الطابور والحالة',
                          badge: pendingSync > 0
                              ? '$pendingSync بانتظار الرفع'
                              : null,
                          onTap: () => context.push('/sync'),
                        ),
                      ],
                    ),

                    // مهام قريبة — فقط للكاشف
                    if (isReader && list.isNotEmpty) ...[
                      const SizedBox(height: 24),
                      Text('مهام قريبة',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium),
                      const SizedBox(height: 8),
                      ...list.take(4).map(
                            (a) => _UpcomingTaskTile(assignment: a),
                          ),
                    ],

                    // رسالة للمحصل فقط
                    if (isCollector && !isReader) ...[
                      const SizedBox(height: 24),
                      Card(
                        child: ListTile(
                          leading: const Icon(
                              Icons.info_outline_rounded),
                          title: const Text(
                              'انتقل لشاشة التحصيل لبدء العمل'),
                          trailing: TextButton(
                            onPressed: () =>
                                context.push('/collector'),
                            child: const Text('انتقل'),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _roleLabel(bool isReader, bool isCollector, bool isSupervisor) {
    final roles = <String>[];
    if (isSupervisor) roles.add('مشرف');
    if (isReader) roles.add('كاشف');
    if (isCollector) roles.add('متحصل');
    return roles.isEmpty ? 'مستخدم' : roles.join(' · ');
  }
}

// ── Widgets ───────────────────────────────────────────────────────────────────

class _ProgressCard extends StatelessWidget {
  final int total, done, pending, pendingSync, synced, failed;
  const _ProgressCard({
    required this.total,
    required this.done,
    required this.pending,
    required this.pendingSync,
    required this.synced,
    required this.failed,
  });

  @override
  Widget build(BuildContext context) {
    final progress = total == 0 ? 0.0 : done / total;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('تقدم قراءات اليوم',
                    style:
                        Theme.of(context).textTheme.titleMedium),
                Text('$done / $total',
                    style:
                        Theme.of(context).textTheme.titleMedium),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                  value: progress, minHeight: 10),
            ),
            const SizedBox(height: 14),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                SyncStatusChip(
                    label: '$pending متبقي',
                    color: Colors.orange,
                    icon: Icons.hourglass_empty_rounded),
                SyncStatusChip(
                    label: '$pendingSync بانتظار الرفع',
                    color: Colors.orange,
                    icon: Icons.schedule_outlined),
                SyncStatusChip(
                    label: '$synced تم الرفع',
                    color: Colors.green,
                    icon: Icons.cloud_done_outlined),
                if (failed > 0)
                  SyncStatusChip(
                      label: '$failed فشل الرفع',
                      color: Colors.red,
                      icon: Icons.error_outline),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final String? badge;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.subtitle,
    this.badge,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon,
                      size: 30,
                      color:
                          Theme.of(context).colorScheme.primary),
                  if (badge != null) ...[
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        badge!,
                        style: const TextStyle(
                            fontSize: 10,
                            color: Colors.orange,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ],
              ),
              const Spacer(),
              Text(label,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w800)),
              Text(subtitle,
                  style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}

class _UpcomingTaskTile extends StatelessWidget {
  final ReadingAssignment assignment;
  const _UpcomingTaskTile({required this.assignment});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        onTap: () => context.push('/customers/${assignment.id}'),
        leading:
            const CircleAvatar(child: Icon(Icons.speed_rounded)),
        title: Text(assignment.customer.name,
            style:
                const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text(
            '${assignment.customer.accountNumber} · عداد ${assignment.meter.meterNumber}'),
        trailing: Text(
          assignment.status == AssignmentStatus.read
              ? 'مكتمل'
              : 'متبقي',
          style: TextStyle(
            color: assignment.status == AssignmentStatus.read
                ? Colors.green
                : Colors.orange,
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
        ),
      ),
    );
  }
}
